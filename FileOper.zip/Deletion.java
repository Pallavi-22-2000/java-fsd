package FileHandling;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;

public class Deletion {
    public static void main(String[] args) {
        // Specify the file path
        String filePath = "C://Users//personal//eclipse-workspace//sample//src//newfile.txt";

        // Create a Path object
        Path path = Paths.get(filePath);

        try {
            // Delete the file
            Files.delete(path);
            System.out.println("File deleted successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
