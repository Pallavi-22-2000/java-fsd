package FileHandling;

import java.io.*;
import java.util.Scanner;
// write data into a file
public class ReadFile {

	public static void main(String[] args) throws  FileNotFoundException, IOException
	{
		Scanner sc = new Scanner(System.in);
		FileOutputStream  fos = new FileOutputStream("C://Users//personal//eclipse-workspace//sample//src//newfile.txt");
		
		System.out.println("Enter Some Text : ");
		String str = sc.nextLine();
		
		byte data[] = str.getBytes();
		
		fos.write(data);
		
		System.out.println("Data has been Saved....");
		
		fos.close();
	}
}
