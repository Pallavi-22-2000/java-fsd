package FileHandling;

import java.io.*;
import java.util.Scanner;
//Create a new File
public class NewFile {

	public static void main(String[] args) throws IOException
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter file name ");
		String fname = sc.next();
		
		File fileObj = new File("C://Users//personal//eclipse-workspace//sample//src" + fname);
		
		if(fileObj.exists())
			System.out.println("File already existed");
		else
		{
			fileObj.createNewFile();
			System.out.println("File created...");
		}
	}
}