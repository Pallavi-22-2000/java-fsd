package constructor;

public class studentinfo {
	
		int id;
		String name;

		studentinfo(int i,String n)
		{
		id=i;
		name=n;
		}

		void display() {
		System.out.println(id+" "+name);
		}
	}



