package constructor;

public class constructordemo {

		public static void main(String[] args) {

			employeeinfo emp1=new employeeinfo();
			employeeinfo emp2=new employeeinfo();

			emp1.display();
			emp2.display();
			}


}
