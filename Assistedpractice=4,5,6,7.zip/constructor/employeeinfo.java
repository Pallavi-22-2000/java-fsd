package constructor;

public class employeeinfo {
	//default constructor
	int id;
	String name;

void display() {
	System.out.println(id+" "+name);
	}
}



