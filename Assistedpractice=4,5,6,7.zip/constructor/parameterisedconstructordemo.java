package constructor;

public class parameterisedconstructordemo {
	
	public static void main(String[] args) {

		studentinfo std1=new studentinfo(2,"Alex");
		studentinfo std2=new studentinfo(10,"Annie");
		std1.display();
		std2.display();
			}


}
