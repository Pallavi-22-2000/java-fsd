// MainController class in the correct package
package com.ecommerce.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ecommerce.repositories.ProductRepository;
import com.ecommerce.models.Product;  // Import statement

@RestController
@RequestMapping("/api")
public class MainController {

    @Autowired
    private ProductRepository repository;

    // Rest of your controller code
}
