package com.ecommerce.models;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Product {
    
    @Id
    private Long id;
    private String name;
    private double price;

    // getters and setters
}
