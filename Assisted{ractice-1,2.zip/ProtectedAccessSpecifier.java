package AccessSpecifiers;

public class ProtectedAccessSpecifier {
	
	public void display()
	{
		System.out.println("this is protected please inherit the claass to access me");
	}


}
