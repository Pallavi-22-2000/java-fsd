package AccessSpecifiers;

public class PublicAccessSpecifier {
	
	public void show()
	{
		System.out.println("this is public access specifier");
	}

	
}
