package AccessSpecifiers;

public class PrivateAccessSpecifier {
	
	public void show()
	{
		System.out.println("this is  a private access specifier");
	}


}
