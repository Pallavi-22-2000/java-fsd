package AccessSpecifiers;

public class DefaultAccessSpecifier {
	
	void display()
	{
		System.out.println("this is default access specifier");
	}

	
}
