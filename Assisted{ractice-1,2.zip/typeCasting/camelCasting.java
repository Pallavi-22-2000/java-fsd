package typeCasting;

public class camelCasting {

		public static void main(String[] args) {
			
			//implicit conversion
			System.out.println("Implicit Type Casting");
			char a='A';
			
			int b=a;
			
			System.out.println("before typecasting a value is:"+a);
			System.out.println("After typecasting to integer a value is:"+b);
			
			float c=a;
			
			System.out.println("before typecasting a value is:"+a);
			System.out.println("After typecasting to float a value is:"+c);
			
			long d=a;
			
			System.out.println("before typecasting a value is:"+a);
			System.out.println("After typecasting to long a value is:"+d);
			
			double e=a;
			
			System.out.println("before typecasting a value is:"+a);
			System.out.println("After typecasting to a value is:"+e);
			
					
			System.out.println("\n");
			
			System.out.println("Explicit Type Casting");
			//explicit conversion
			
			double x=45.5;
			int y=(int)x;
			System.out.println("before  typecasting the Value of x: "+x);
			System.out.println("After  typecasting to integer the Value of y: "+y);
			
		}
	}


