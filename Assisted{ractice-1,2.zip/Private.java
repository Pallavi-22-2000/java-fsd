package AccessSpecifiers;

public class Private {
	
	public static void main(String[] args) {
		System.out.println("Private access specifier");
		PrivateAccessSpecifier obj=new PrivateAccessSpecifier();
		//try to access private method of another class
		//obj.display();
	}

}
