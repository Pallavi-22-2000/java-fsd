package pacakge2;
import AccessSpecifiers.*;
public class Public {
	
	public static void main(String[] args) {
		PublicAccessSpecifier p=new PublicAccessSpecifier();
		p.show();
	}

}
