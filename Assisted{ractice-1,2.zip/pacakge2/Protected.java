package pacakge2;
import AccessSpecifiers.*;
public class Protected {
	
	public static void main(String[] args) {
		ProtectedAccessSpecifier p=new ProtectedAccessSpecifier();
		p.display();
	}

}
