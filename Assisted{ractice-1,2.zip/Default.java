package AccessSpecifiers;

public class Default {

	public static void main(String[] args) {
		System.out.println("Default AccessSpecifier");
		DefaultAccessSpecifier obj = new DefaultAccessSpecifier();
		obj.display();
	}
}
	
