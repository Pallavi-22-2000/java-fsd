package com.ecommerce;

public class ScreenSizes {

}
