package com.ecommerce;

public class Color {

}
