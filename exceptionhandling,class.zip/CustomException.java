package ExceptionHandling;

class CustomException1 extends Exception 
{ 
    public CustomException(String s) 
    { 
        super(s); 
    } 
} 

public class CustomException 
{ 
    public static void main(String args[]) 
    { 
        try
        { 
            throw new CustomException1("temp"); 
        } 
        catch (CustomException1 ex) 
        { 
            System.out.println("Caught"); 
            System.out.println(ex.getMessage()); 
        } 
    } 
}
