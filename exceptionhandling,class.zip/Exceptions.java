package ExceptionHandling;

public class Exceptions {

	public static void main(String[] args) {
		System.out.println("exception handling demo program starts here...");
		try {
			// uncommenting below will throw ArithmeticException
			int num = 28/0;
			//int arr[] = (10,20,30,40,50,60);
			//uncommenting below will throw ArrayIndexoutofboundsexception
			//System.out.println(arr[10]);
			//String str = null;
			//uncommenting below will throw nullpointerexception
			//System.out.println(str.length());
			
		}
		
		catch(ArithmeticException e)
		{
			System.out.println("Denominator should not be zero while dividing number...");
			System.out.println("error:" + e);
		}
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("user is trying to access index location outside the array boundary");
			System.out.println("error:" + e);
		}

		
		catch(NullPointerException e)
		{
			System.out.println("user is trying to perform operations on null value");
			System.out.println("error:" + e);
		}
		finally {//block executes even when there is error in code with no errors
			System.out.println("this block always executes");
		}
		System.out.println("exception handling demo program ends here...");
	}
}	
						
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
	
