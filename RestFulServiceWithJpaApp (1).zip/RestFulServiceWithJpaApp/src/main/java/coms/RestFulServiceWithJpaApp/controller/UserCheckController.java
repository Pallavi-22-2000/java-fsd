package coms.RestFulServiceWithJpaApp.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import coms.RestFulServiceWithJpaApp.Entities.Employee;
import coms.RestFulServiceWithJpaApp.repo.EmployeeRepo;
import coms.RestFulServiceWithJpaApp.service.EmpService;

@RestController
public class UserCheckController {

	@Autowired
	EmpService es;
	
	/*
	@GetMapping("/users/{email}/{pwd}")
	public ResponseEntity<Object> UserCheck(@PathVariable String email, @PathVariable String pwd)
	{
		List<Employee> emplist = es.ShowAll();
		Employee empinfo = null;
		boolean b = false;
		for(Employee e : emplist)
		{
			if(e.getEmail().equals(email) && e.getPswd().equals(pwd))
			{
				b = true;
				empinfo = e;
				break;
			}
		}
		
		if(b==true)
			return new ResponseEntity<Object>(empinfo, HttpStatus.OK);
		return new ResponseEntity<Object>("Employee Not Found", HttpStatus.NOT_FOUND);
	}
	*/
	
	@GetMapping("/users/{email}/{pwd}")
	public ResponseEntity<Object> UserCheck(@PathVariable String email, @PathVariable String pwd)
	{
		System.out.println(email);
		
		Employee emps = es.LoginUser(email, pwd);
		
		if(emps!=null)
			return new ResponseEntity<Object>(emps, HttpStatus.OK);
		
		return new ResponseEntity<Object>("Employee Not Found", HttpStatus.NOT_FOUND);
	}
}
