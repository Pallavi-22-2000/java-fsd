package coms.RestFulServiceWithJpaApp.Entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="emp_info_jpa")

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor

public class Employee {

	@Id
	@GeneratedValue
	private int empno;
	
	private String ename;
	private String job;
	private float salary;
	private String email, pswd;
	
}
